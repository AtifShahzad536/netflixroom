var G=Object.defineProperty;var j=(r,t,e)=>t in r?G(r,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):r[t]=e;var o=(r,t,e)=>j(r,typeof t!="symbol"?t+"":t,e);import{v as w,s as m}from"./assets/voice-service-DDGkbpFB.js";import{S as b}from"./assets/storage-service-cKEFeWJs.js";const E=class E{constructor(){o(this,"videoElement",null);o(this,"isApplyingRemoteAction",!1);o(this,"remoteActionTimeout",null);this.detectVideoElement()}static getInstance(){return E.instance||(E.instance=new E),E.instance}detectVideoElement(){if(this.videoElement&&document.contains(this.videoElement))return this.videoElement;const t=document.querySelector("video")||document.querySelector(".watch-video--player-view video")||document.querySelector(".nf-player-container video");return t instanceof HTMLVideoElement?(this.videoElement=t,t):(this.videoElement=null,null)}isAvailable(){return!!this.detectVideoElement()}getCurrentTime(){const t=this.detectVideoElement();return t?t.currentTime:0}getDuration(){const t=this.detectVideoElement();return t&&t.duration||0}isPlaying(){const t=this.detectVideoElement();return t?!t.paused&&!t.ended&&t.readyState>2:!1}setRemoteActionFlag(t=800){this.isApplyingRemoteAction=!0,this.remoteActionTimeout&&clearTimeout(this.remoteActionTimeout),this.remoteActionTimeout=window.setTimeout(()=>{this.isApplyingRemoteAction=!1,this.remoteActionTimeout=null},t)}isHandlingRemoteAction(){return this.isApplyingRemoteAction}async play(){const t=this.detectVideoElement();if(t){this.setRemoteActionFlag();try{t.paused&&await t.play()}catch(e){console.warn("[NetflixAdapter] Play failed:",e)}}}pause(){const t=this.detectVideoElement();if(t){this.setRemoteActionFlag();try{t.paused||t.pause()}catch(e){console.warn("[NetflixAdapter] Pause failed:",e)}}}seek(t,e=.3){const i=this.detectVideoElement();if(!(!i||Math.abs(i.currentTime-t)<e)){this.setRemoteActionFlag();try{i.currentTime=t}catch(a){console.warn("[NetflixAdapter] Seek failed:",a)}}}getMediaInfo(){let t="Netflix Stream",e="";try{const i=document.querySelector('[data-uia="video-title"]')||document.querySelector(".video-title h4")||document.querySelector(".ellipsize-text");if(i&&i.textContent)t=i.textContent.trim();else{const a=document.title.replace(" - Netflix","").trim();a&&a!=="Netflix"&&(t=a)}const n=document.querySelector(".video-title span");n&&n.textContent&&(e=n.textContent.trim())}catch{}return{title:t,episodeInfo:e,videoUrl:window.location.href,duration:this.getDuration()}}};o(E,"instance");let A=E;const C=class C{constructor(){o(this,"adapter");o(this,"currentUser",null);o(this,"activeParty",null);o(this,"messages",[]);o(this,"inVoice",!1);o(this,"isMuted",!0);o(this,"isSpeaking",!1);o(this,"connectionStatus","disconnected");this.adapter=A.getInstance(),this.init()}static getInstance(){return C.instance||(C.instance=new C),C.instance}async init(){const t=await b.getUser();if(t)this.currentUser=t;else{const n={userId:`usr-${Date.now()}-${Math.random().toString(36).substr(2,4)}`,name:`Watcher_${Math.floor(100+Math.random()*900)}`};this.currentUser=n,await b.setUser(n)}w.setOnSpeakingChange(n=>{this.isSpeaking=n,this.activeParty&&this.currentUser&&(this.activeParty.members=this.activeParty.members.map(a=>{var c;return a.userId===((c=this.currentUser)==null?void 0:c.userId)?{...a,isSpeaking:n}:a})),this.syncState(!1)}),w.setOnPermissionGranted(async()=>{(await w.startVoice()).success&&(this.inVoice=!0,this.isMuted=!1,this.activeParty&&this.currentUser&&(this.activeParty.members=this.activeParty.members.map(a=>{var c;return a.userId===((c=this.currentUser)==null?void 0:c.userId)?{...a,inVoice:!0,isMuted:!1}:a})),this.syncState(!0))}),this.setupSocketListeners(),this.setupStorageListeners();const e=await b.getActivePartyCode(),i=await b.getPartySession();e&&this.currentUser?(i&&i.party&&i.party.partyCode===e&&(this.activeParty=i.party,this.messages=i.messages||[],this.inVoice=!!i.inVoice,this.isMuted=i.isMuted!==void 0?i.isMuted:!0,this.syncState()),this.joinParty(e,this.currentUser).then(()=>{i!=null&&i.inVoice&&!this.inVoice&&this.toggleVoice().catch(()=>{})}).catch(()=>{})):this.syncState()}setupStorageListeners(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener(async(e,i)=>{var n,a,c;if(i==="local"){if((n=e.netflix_wp_user)!=null&&n.newValue&&(this.currentUser=e.netflix_wp_user.newValue),e.netflix_wp_active_party||e.netflix_wp_active_party_code){const p=((a=e.netflix_wp_active_party)==null?void 0:a.newValue)||((c=e.netflix_wp_active_party_code)==null?void 0:c.newValue);!p&&this.activeParty?this.leaveParty():p&&(!this.activeParty||this.activeParty.partyCode!==p)&&this.currentUser&&await this.joinParty(p,this.currentUser)}if(e.netflix_wp_party_session){const p=e.netflix_wp_party_session.newValue;if(p&&p.party){if(!this.currentUser&&p.currentUser&&(this.currentUser=p.currentUser),!this.activeParty||this.activeParty.partyCode!==p.party.partyCode){const d=this.currentUser||p.currentUser;d&&await this.joinParty(p.party.partyCode,d)}}else!p&&this.activeParty&&this.leaveParty()}}})}setupSocketListeners(){m.onStatusChange(t=>{this.connectionStatus=t,this.syncState()}),m.onPlay(t=>{this.activeParty&&(this.activeParty.playbackState={...this.activeParty.playbackState,isPlaying:!0,currentTime:t.position,lastUpdated:Date.now()}),typeof t.position=="number"&&this.adapter.seek(t.position),this.adapter.play(),this.syncState()}),m.onPause(t=>{this.activeParty&&(this.activeParty.playbackState={...this.activeParty.playbackState,isPlaying:!1,currentTime:t.position,lastUpdated:Date.now()}),typeof t.position=="number"&&this.adapter.seek(t.position),this.adapter.pause(),this.syncState()}),m.onSeek(t=>{this.activeParty&&(this.activeParty.playbackState={...this.activeParty.playbackState,currentTime:t.position,lastUpdated:Date.now()}),typeof t.position=="number"&&this.adapter.seek(t.position),this.syncState()}),m.onChatMessage(t=>{this.messages.some(e=>e.id===t.id)||(this.messages=[...this.messages,t],this.syncState())}),m.onMemberJoined(({member:t})=>{this.activeParty&&(this.activeParty.members.some(i=>i.userId===t.userId)||(this.activeParty.members=[...this.activeParty.members,t])),this.syncState()}),m.onMemberLeft(({userId:t,newHostId:e})=>{this.activeParty&&(this.activeParty.members=this.activeParty.members.filter(i=>i.userId!==t),e&&(this.activeParty.hostId=e)),this.syncState()}),m.onVoiceJoined(({userId:t})=>{this.activeParty&&(this.activeParty.members=this.activeParty.members.map(e=>e.userId===t?{...e,inVoice:!0,isMuted:!1}:e)),this.syncState()}),m.onVoiceLeft(({userId:t})=>{this.activeParty&&(this.activeParty.members=this.activeParty.members.map(e=>e.userId===t?{...e,inVoice:!1,isSpeaking:!1}:e)),this.syncState()}),m.onVoiceSpeaking(({userId:t,isSpeaking:e})=>{var i;this.activeParty&&(this.activeParty.members=this.activeParty.members.map(n=>n.userId===t?{...n,isSpeaking:e}:n)),t===((i=this.currentUser)==null?void 0:i.userId)&&(this.isSpeaking=e),this.syncState(!1)}),m.onVoiceStateChange(({userId:t,isMuted:e})=>{this.activeParty&&(this.activeParty.members=this.activeParty.members.map(i=>i.userId===t?{...i,isMuted:e}:i)),this.syncState(!0)}),m.onMediaUpdate(t=>{this.activeParty&&(this.activeParty.mediaInfo=t),this.syncState(!0)})}syncState(t=!0){const e={party:this.activeParty,inVoice:this.inVoice,isMuted:this.isMuted,isSpeaking:this.isSpeaking,messages:this.messages,currentUser:this.currentUser,connectionStatus:this.connectionStatus};t&&b.setPartySession(e).catch(()=>{}),U.updateState(e),chrome.runtime.sendMessage({type:"PARTY_ENGINE_STATE_CHANGED",payload:e}).catch(()=>{})}getState(){return{party:this.activeParty,inVoice:this.inVoice,isMuted:this.isMuted,isSpeaking:this.isSpeaking,messages:this.messages,currentUser:this.currentUser,connectionStatus:this.connectionStatus}}async joinParty(t,e){const i=e||this.currentUser;this.currentUser=i,await b.setUser(i);const n=await m.joinParty(t,i);if(n.success&&n.party)return this.activeParty=n.party,n.messages&&(this.messages=n.messages),await b.setActivePartyCode(n.party.partyCode),this.syncState(),n;{const a={partyCode:t,name:"Watch Party",hostId:i.userId,hostName:i.name,members:[{userId:i.userId,name:i.name,isHost:!0,isMuted:!0,isSpeaking:!1,inVoice:!1}],mediaInfo:this.adapter.getMediaInfo()||{title:"Netflix Stream"},playbackState:{isPlaying:this.adapter.isPlaying(),currentTime:this.adapter.getCurrentTime(),lastUpdated:Date.now()},settings:{onlyHostCanControl:!1,isVoiceEnabled:!0,maxMembers:20},isActive:!0};return this.activeParty=a,await b.setActivePartyCode(t),this.syncState(),{success:!0,party:a,messages:[]}}}async createParty(t,e,i){var n,a;try{const d=await(await fetch("https://netflixroom.vercel.app/api/party/create",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:t,description:e,hostId:(n=this.currentUser)==null?void 0:n.userId,hostName:(a=this.currentUser)==null?void 0:a.name,settings:{onlyHostCanControl:i,isVoiceEnabled:!0,maxMembers:20}})})).json();if(d.success&&d.party)return await this.joinParty(d.party.partyCode,this.currentUser),d.party;throw new Error("API failed")}catch{const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let p="WP-";for(let s=0;s<4;s++)p+=c.charAt(Math.floor(Math.random()*c.length));const d={partyCode:p,name:t,description:e,hostId:this.currentUser.userId,hostName:this.currentUser.name,members:[{userId:this.currentUser.userId,name:this.currentUser.name,isHost:!0,isMuted:!0,isSpeaking:!1,inVoice:!1}],mediaInfo:this.adapter.getMediaInfo()||{title:"Netflix Stream"},playbackState:{isPlaying:this.adapter.isPlaying(),currentTime:this.adapter.getCurrentTime(),lastUpdated:Date.now()},settings:{onlyHostCanControl:i,isVoiceEnabled:!0,maxMembers:20},isActive:!0};return await this.joinParty(p,this.currentUser),d}}leaveParty(){this.inVoice&&(w.stopVoice(),this.inVoice=!1,this.isMuted=!0,this.isSpeaking=!1),m.leaveParty(),this.activeParty=null,this.messages=[],b.setActivePartyCode(null).catch(()=>{}),this.syncState()}async toggleVoice(){if(this.inVoice)w.stopVoice(),this.inVoice=!1,this.isMuted=!0,this.isSpeaking=!1,this.activeParty&&this.currentUser&&(this.activeParty.members=this.activeParty.members.map(t=>{var e;return t.userId===((e=this.currentUser)==null?void 0:e.userId)?{...t,inVoice:!1,isSpeaking:!1}:t})),this.syncState();else{const t=await w.startVoice();t.success?(this.inVoice=!0,this.isMuted=!1,this.activeParty&&this.currentUser&&(this.activeParty.members=this.activeParty.members.map(e=>{var i;return e.userId===((i=this.currentUser)==null?void 0:i.userId)?{...e,inVoice:!0,isMuted:!1}:e})),this.syncState()):t.requiresPermissionTab&&w.openPermissionTab()}}async setVoiceState(t,e){this.inVoice=t,e!==void 0&&(this.isMuted=e),t&&!w.getIsConnected()?await w.startVoice():!t&&w.getIsConnected()&&w.stopVoice(),this.activeParty&&this.currentUser&&(this.activeParty.members=this.activeParty.members.map(i=>{var n;return i.userId===((n=this.currentUser)==null?void 0:n.userId)?{...i,inVoice:t,isMuted:this.isMuted}:i})),this.syncState()}toggleMute(){const t=w.toggleMute();return this.isMuted=t,this.activeParty&&this.currentUser&&(this.activeParty.members=this.activeParty.members.map(e=>{var i;return e.userId===((i=this.currentUser)==null?void 0:i.userId)?{...e,isMuted:t}:e})),this.syncState(),t}async sendMessage(t,e="chat",i){if(!(!t&&!i)){if(this.currentUser||(this.currentUser=await b.getUser()),!this.activeParty){const n=await b.getActivePartyCode(),a=await b.getPartySession();a!=null&&a.party?this.activeParty=a.party:n&&this.currentUser&&await this.joinParty(n,this.currentUser)}if(this.activeParty&&this.currentUser){const n=m.getSocket();(!n||!n.connected)&&await m.joinParty(this.activeParty.partyCode,this.currentUser)}await m.sendMessage(t,e,i)}}togglePlay(){if(!this.activeParty)return;const t=!this.activeParty.playbackState.isPlaying,e=this.adapter.getCurrentTime();t?(m.sendPlay(e),this.adapter.play()):(m.sendPause(e),this.adapter.pause())}forceSync(){this.activeParty&&this.adapter.seek(this.activeParty.playbackState.currentTime)}handleLocalPlay(t){var i;if(!this.activeParty)return;(!this.activeParty.settings.onlyHostCanControl||this.activeParty.hostId===((i=this.currentUser)==null?void 0:i.userId))&&m.sendPlay(t)}handleLocalPause(t){var i;if(!this.activeParty)return;(!this.activeParty.settings.onlyHostCanControl||this.activeParty.hostId===((i=this.currentUser)==null?void 0:i.userId))&&m.sendPause(t)}handleLocalSeek(t){var i;if(!this.activeParty)return;(!this.activeParty.settings.onlyHostCanControl||this.activeParty.hostId===((i=this.currentUser)==null?void 0:i.userId))&&m.sendSeek(t)}handleMediaUpdate(t){this.activeParty&&t!=null&&t.title&&(!this.activeParty.mediaInfo.title||this.activeParty.mediaInfo.title==="Netflix Stream")&&m.sendMediaUpdate(t)}};o(C,"instance");let L=C;const l=L.getInstance(),M=class M{constructor(){o(this,"container",null);o(this,"dockElement",null);o(this,"chatDrawerElement",null);o(this,"isChatOpen",!1);o(this,"isCollapsed",!1);o(this,"unreadCount",0);o(this,"party",null);o(this,"inVoice",!1);o(this,"isMuted",!0);o(this,"isSpeaking",!1);o(this,"messages",[]);o(this,"renderedMessageIds",new Set);o(this,"currentUser",null);o(this,"lastPartyCode","");o(this,"hideTimeout",null);o(this,"isMouseInside",!1);o(this,"lastRenderedMembersHash","");this.injectStyles(),this.setupFullscreenListeners(),this.setupInactivityFade()}static getInstance(){return M.instance||(M.instance=new M),M.instance}init(){this.injectStyles(),this.ensureDOMStructure(),this.updateDOM()}updateState(t){if(t.party!==void 0&&(this.party=t.party),t.inVoice!==void 0&&(this.inVoice=t.inVoice),t.isMuted!==void 0&&(this.isMuted=t.isMuted),t.isSpeaking!==void 0&&(this.isSpeaking=t.isSpeaking),t.currentUser!==void 0&&(this.currentUser=t.currentUser),t.messages!==void 0){const e=this.messages.length;this.messages=t.messages,!this.isChatOpen&&t.messages.length>e&&(this.unreadCount+=t.messages.length-e)}this.updateDOM()}injectStyles(){if(document.getElementById("nwp-floating-styles"))return;const t=document.createElement("style");t.id="nwp-floating-styles",t.textContent=`
      #nwp-floating-root {
        position: fixed !important;
        left: 18px !important;
        top: 50% !important;
        transform: translateY(-50%) !important;
        z-index: 2147483647 !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        display: flex !important;
        align-items: center !important;
        gap: 12px !important;
        user-select: none !important;
        transition: opacity 0.3s cubic-bezier(0.16, 1, 0.3, 1), transform 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
        pointer-events: auto !important;
        line-height: normal !important;
      }

      #nwp-floating-root.nwp-dimmed {
        opacity: 0.35 !important;
      }

      #nwp-floating-root.nwp-dimmed:hover {
        opacity: 1 !important;
      }

      /* Vertical Dock */
      .nwp-dock {
        background: rgba(15, 17, 24, 0.94) !important;
        backdrop-filter: blur(24px) !important;
        -webkit-backdrop-filter: blur(24px) !important;
        border: 1px solid rgba(255, 255, 255, 0.15) !important;
        box-shadow: 0 16px 40px rgba(0, 0, 0, 0.75), 0 0 0 1px rgba(229, 9, 20, 0.25) !important;
        border-radius: 20px !important;
        padding: 10px 8px !important;
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important;
        gap: 10px !important;
        transition: transform 0.25s ease, opacity 0.25s ease !important;
      }

      .nwp-dock.nwp-collapsed {
        transform: translateX(-36px) !important;
        padding: 8px 4px !important;
        opacity: 0.75 !important;
      }

      .nwp-dock.nwp-collapsed:hover {
        transform: translateX(0) !important;
        opacity: 1 !important;
      }

      /* Buttons */
      .nwp-btn {
        position: relative !important;
        width: 42px !important;
        height: 42px !important;
        border-radius: 12px !important;
        background: rgba(255, 255, 255, 0.08) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        color: #f1f5f9 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        transition: background 0.2s ease, border-color 0.2s ease, transform 0.15s ease, box-shadow 0.2s ease !important;
        outline: none !important;
        box-sizing: border-box !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      .nwp-btn:hover {
        background: rgba(255, 255, 255, 0.18) !important;
        border-color: rgba(255, 255, 255, 0.3) !important;
        transform: scale(1.06) !important;
      }

      .nwp-btn:active {
        transform: scale(0.96) !important;
      }

      .nwp-btn.nwp-logo-btn {
        background: linear-gradient(135deg, #e50914, #b20710) !important;
        border-color: rgba(229, 9, 20, 0.6) !important;
        box-shadow: 0 4px 14px rgba(229, 9, 20, 0.45) !important;
      }

      /* Mic Button States */
      .nwp-btn.nwp-mic-off {
        background: rgba(255, 255, 255, 0.08) !important;
        border-color: rgba(255, 255, 255, 0.1) !important;
        color: #94a3b8 !important;
      }

      .nwp-btn.nwp-mic-muted {
        background: rgba(239, 68, 68, 0.25) !important;
        border-color: rgba(239, 68, 68, 0.5) !important;
        color: #f87171 !important;
      }

      .nwp-btn.nwp-mic-active {
        background: rgba(16, 185, 129, 0.25) !important;
        border-color: rgba(16, 185, 129, 0.6) !important;
        color: #34d399 !important;
      }

      .nwp-btn.nwp-mic-speaking {
        box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.6), 0 0 16px rgba(16, 185, 129, 0.5) !important;
        border-color: #34d399 !important;
      }

      /* Badge Counter */
      .nwp-badge {
        position: absolute !important;
        top: -4px !important;
        right: -4px !important;
        background: #e50914 !important;
        color: #ffffff !important;
        font-size: 10px !important;
        font-weight: 700 !important;
        min-width: 18px !important;
        height: 18px !important;
        border-radius: 9px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 0 4px !important;
        border: 2px solid #0f1118 !important;
      }

      /* Tooltip */
      .nwp-tooltip {
        position: absolute !important;
        left: calc(100% + 12px) !important;
        background: #181b24 !important;
        color: #f8fafc !important;
        padding: 6px 12px !important;
        border-radius: 8px !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        white-space: nowrap !important;
        pointer-events: none !important;
        opacity: 0 !important;
        transform: translateX(-4px) !important;
        transition: opacity 0.15s ease, transform 0.15s ease !important;
        border: 1px solid rgba(255, 255, 255, 0.15) !important;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.5) !important;
        z-index: 1000 !important;
      }

      .nwp-btn:hover .nwp-tooltip {
        opacity: 1 !important;
        transform: translateX(0) !important;
      }

      /* Chat Drawer */
      .nwp-chat-drawer {
        width: 330px !important;
        height: 440px !important;
        background: rgba(14, 16, 22, 0.96) !important;
        backdrop-filter: blur(24px) !important;
        -webkit-backdrop-filter: blur(24px) !important;
        border: 1px solid rgba(255, 255, 255, 0.16) !important;
        box-shadow: 0 20px 48px rgba(0, 0, 0, 0.8) !important;
        border-radius: 20px !important;
        display: none !important;
        flex-direction: column !important;
        overflow: hidden !important;
      }

      .nwp-chat-drawer.nwp-open {
        display: flex !important;
      }

      .nwp-chat-header {
        padding: 14px 16px !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        background: rgba(255, 255, 255, 0.02) !important;
      }

      .nwp-chat-title {
        font-size: 13px !important;
        font-weight: 700 !important;
        color: #f8fafc !important;
        display: flex !important;
        align-items: center !important;
        gap: 6px !important;
      }

      .nwp-chat-code {
        font-size: 11px !important;
        padding: 2px 6px !important;
        background: rgba(229, 9, 20, 0.2) !important;
        color: #f87171 !important;
        border-radius: 4px !important;
        font-weight: 600 !important;
      }

      .nwp-chat-close {
        background: transparent !important;
        border: none !important;
        color: #94a3b8 !important;
        cursor: pointer !important;
        padding: 4px !important;
        border-radius: 6px !important;
        display: flex !important;
      }

      .nwp-chat-close:hover {
        background: rgba(255, 255, 255, 0.1) !important;
        color: #ffffff !important;
      }

      .nwp-chat-body {
        flex: 1 !important;
        overflow-y: auto !important;
        padding: 12px !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 8px !important;
      }

      .nwp-msg-bubble {
        max-width: 85% !important;
        padding: 8px 12px !important;
        border-radius: 12px !important;
        font-size: 12px !important;
        line-height: 1.4 !important;
        word-break: break-word !important;
      }

      .nwp-msg-mine {
        align-self: flex-end !important;
        background: linear-gradient(135deg, #e50914, #c90711) !important;
        color: #ffffff !important;
        border-bottom-right-radius: 3px !important;
      }

      .nwp-msg-other {
        align-self: flex-start !important;
        background: rgba(255, 255, 255, 0.08) !important;
        color: #e2e8f0 !important;
        border-bottom-left-radius: 3px !important;
      }

      .nwp-msg-system {
        align-self: center !important;
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        color: #94a3b8 !important;
        font-size: 10px !important;
        padding: 4px 8px !important;
      }

      .nwp-msg-sender {
        font-size: 10px !important;
        font-weight: 600 !important;
        color: #94a3b8 !important;
        margin-bottom: 2px !important;
      }

      .nwp-reactions-bar {
        display: flex !important;
        gap: 4px !important;
        padding: 6px 12px !important;
        background: rgba(255, 255, 255, 0.03) !important;
        border-top: 1px solid rgba(255, 255, 255, 0.06) !important;
      }

      .nwp-reaction-btn {
        background: transparent !important;
        border: none !important;
        font-size: 15px !important;
        cursor: pointer !important;
        padding: 2px 5px !important;
        border-radius: 6px !important;
        transition: transform 0.15s !important;
      }

      .nwp-reaction-btn:hover {
        transform: scale(1.25) !important;
        background: rgba(255, 255, 255, 0.1) !important;
      }

      .nwp-chat-input-row {
        padding: 10px 12px !important;
        border-top: 1px solid rgba(255, 255, 255, 0.08) !important;
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
      }

      .nwp-chat-input {
        flex: 1 !important;
        background: rgba(255, 255, 255, 0.07) !important;
        border: 1px solid rgba(255, 255, 255, 0.12) !important;
        color: #ffffff !important;
        border-radius: 10px !important;
        padding: 8px 12px !important;
        font-size: 12px !important;
        outline: none !important;
      }

      .nwp-chat-input:focus {
        border-color: #e50914 !important;
      }

      .nwp-send-btn {
        background: #e50914 !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 10px !important;
        width: 34px !important;
        height: 34px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        transition: background 0.15s !important;
      }

      .nwp-send-btn:hover {
        background: #b80710 !important;
      }

      /* Members Tooltip Card */
      .nwp-members-card {
        position: absolute !important;
        left: calc(100% + 12px) !important;
        top: 60px !important;
        background: rgba(14, 16, 22, 0.95) !important;
        backdrop-filter: blur(20px) !important;
        border: 1px solid rgba(255, 255, 255, 0.12) !important;
        box-shadow: 0 16px 36px rgba(0, 0, 0, 0.65) !important;
        border-radius: 14px !important;
        padding: 10px !important;
        width: 180px !important;
        display: none !important;
        flex-direction: column !important;
        gap: 6px !important;
        z-index: 1000 !important;
      }

      .nwp-members-btn:hover .nwp-members-card {
        display: flex !important;
      }

      .nwp-member-row {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        font-size: 11px !important;
        color: #e2e8f0 !important;
      }
    `,(document.head||document.documentElement).appendChild(t)}setupFullscreenListeners(){const t=()=>{const e=document.fullscreenElement||document.webkitFullscreenElement;this.container&&(e&&!e.contains(this.container)?e.appendChild(this.container):!e&&document.body&&!document.body.contains(this.container)&&document.body.appendChild(this.container))};document.addEventListener("fullscreenchange",t),document.addEventListener("webkitfullscreenchange",t)}setupInactivityFade(){}ensureDOMStructure(){let t=document.getElementById("nwp-floating-root");if(!t){t=document.createElement("div"),t.id="nwp-floating-root",t.addEventListener("mouseenter",()=>{this.isMouseInside=!0,t.classList.remove("nwp-dimmed")}),t.addEventListener("mouseleave",()=>{this.isMouseInside=!1});const e=document.fullscreenElement||document.webkitFullscreenElement;e?e.appendChild(t):document.body?document.body.appendChild(t):document.documentElement.appendChild(t)}if(this.container=t,!this.dockElement||!t.contains(this.dockElement)){const e=document.createElement("div");e.className="nwp-dock",e.id="nwp-dock",e.innerHTML=`
        <button class="nwp-btn nwp-logo-btn" id="nwp-btn-logo">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
            <path d="M4 3h3l7 14V3h3v18h-3L7 7v14H4V3z"/>
          </svg>
          <span class="nwp-tooltip" id="nwp-logo-tooltip">Netflix Watch Party</span>
        </button>
        <button class="nwp-btn nwp-mic-off" id="nwp-btn-mic" style="display:none;">
          <svg class="nwp-icon-mic-on" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none;">
            <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
            <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
            <line x1="12" y1="19" x2="12" y2="22"></line>
          </svg>
          <svg class="nwp-icon-mic-off" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="2" y1="2" x2="22" y2="22"></line>
            <path d="M18.89 13.23A7.12 7.12 0 0 0 19 12v-2"></path>
            <path d="M5 10v2a7 7 0 0 0 12 5"></path>
            <path d="M15 9.34V5a3 3 0 0 0-5.68-1.33"></path>
            <path d="M9 9v3a3 3 0 0 0 5.12 2.12"></path>
            <line x1="12" y1="19" x2="12" y2="22"></line>
          </svg>
          <span class="nwp-tooltip" id="nwp-mic-tooltip">Join Voice Chat</span>
        </button>
        <button class="nwp-btn" id="nwp-btn-chat" style="display:none;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
          <span class="nwp-badge" id="nwp-badge" style="display:none;">0</span>
          <span class="nwp-tooltip">Party Chat</span>
        </button>
        <button class="nwp-btn nwp-members-btn" id="nwp-btn-members" style="display:none;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
            <circle cx="9" cy="7" r="4"></circle>
            <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
          </svg>
          <span class="nwp-tooltip" id="nwp-members-tooltip">Members (1)</span>
          <div class="nwp-members-card" id="nwp-members-card"></div>
        </button>
        <button class="nwp-btn" id="nwp-btn-resync" style="display:none;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
          </svg>
          <span class="nwp-tooltip">Resync Stream</span>
        </button>
        <button class="nwp-btn" id="nwp-btn-sidepanel">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
            <line x1="15" y1="3" x2="15" y2="21"></line>
          </svg>
          <span class="nwp-tooltip">Open Sidebar</span>
        </button>
      `;const i=e.querySelector("#nwp-btn-logo");i.onclick=d=>{d.stopPropagation(),this.party&&this.party.partyCode?(this.isCollapsed=!this.isCollapsed,e.className=`nwp-dock ${this.isCollapsed?"nwp-collapsed":""}`):chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})};const n=e.querySelector("#nwp-btn-mic");n.onclick=d=>{d.stopPropagation(),this.inVoice?l.toggleMute():l.toggleVoice()};const a=e.querySelector("#nwp-btn-chat");a.onclick=d=>{d.stopPropagation(),this.toggleChat()};const c=e.querySelector("#nwp-btn-resync");c.onclick=d=>{d.stopPropagation(),l.forceSync()};const p=e.querySelector("#nwp-btn-sidepanel");p.onclick=d=>{d.stopPropagation(),chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})},t.appendChild(e),this.dockElement=e}if(!this.chatDrawerElement||!t.contains(this.chatDrawerElement)){const e=document.createElement("div");e.className="nwp-chat-drawer",e.id="nwp-chat-drawer",e.innerHTML=`
        <div class="nwp-chat-header">
          <div class="nwp-chat-title">
            <span>Party Chat</span>
            <span class="nwp-chat-code" id="nwp-drawer-code"></span>
          </div>
          <button class="nwp-chat-close" id="nwp-drawer-close">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
        <div class="nwp-chat-body" id="nwp-chat-body"></div>
        <div class="nwp-reactions-bar" id="nwp-reactions-bar"></div>
        <div class="nwp-chat-input-row">
          <input type="text" class="nwp-chat-input" id="nwp-chat-input" placeholder="Message friends..." />
          <button class="nwp-send-btn" id="nwp-send-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </button>
        </div>
      `;const i=e.querySelector("#nwp-drawer-close");i.onclick=s=>{s.stopPropagation(),this.toggleChat(!1)};const n=["🔥","❤️","😂","🍿","😱","🎉"],a=e.querySelector("#nwp-reactions-bar");n.forEach(s=>{const h=document.createElement("button");h.className="nwp-reaction-btn",h.innerText=s,h.onclick=N=>{N.stopPropagation(),this.sendMessage(s,"sticker",s)},a.appendChild(h)});const c=e.querySelector("#nwp-chat-input"),p=e.querySelector("#nwp-send-btn"),d=()=>{const s=c.value.trim();s&&(this.sendMessage(s,"chat"),c.value="",c.focus())};c.addEventListener("keydown",s=>{var h;s.stopPropagation(),(h=s.stopImmediatePropagation)==null||h.call(s),s.key==="Enter"&&(s.preventDefault(),d()),s.key==="Escape"&&this.toggleChat(!1)}),c.addEventListener("keyup",s=>{var h;s.stopPropagation(),(h=s.stopImmediatePropagation)==null||h.call(s)}),c.addEventListener("keypress",s=>{var h;s.stopPropagation(),(h=s.stopImmediatePropagation)==null||h.call(s)}),p.onclick=s=>{s.stopPropagation(),d()},t.appendChild(e),this.chatDrawerElement=e}}updateDOM(){var p,d,s,h,N;this.ensureDOMStructure();const t=!!(this.party&&this.party.partyCode),e=document.getElementById("nwp-logo-tooltip");if(e){const u=t?`Party: ${(p=this.party)==null?void 0:p.partyCode}`:"Netflix Watch Party (Open Sidebar)";e.innerText!==u&&(e.innerText=u)}const i=document.getElementById("nwp-btn-mic"),n=document.getElementById("nwp-btn-chat"),a=document.getElementById("nwp-btn-members"),c=document.getElementById("nwp-btn-resync");if(i&&n&&a&&c){const u=t?"flex":"none";if(i.style.display!==u&&(i.style.display=u),n.style.display!==u&&(n.style.display=u),a.style.display!==u&&(a.style.display=u),c.style.display!==u&&(c.style.display=u),t){let S="nwp-btn ";this.inVoice?this.isMuted?S+="nwp-mic-muted":S+="nwp-mic-active"+(this.isSpeaking?" nwp-mic-speaking":""):S+="nwp-mic-off",i.className!==S&&(i.className=S);const v=document.getElementById("nwp-mic-tooltip");if(v){const f=this.inVoice?this.isMuted?"Unmute Microphone":"Mute Microphone":"Join Voice Chat";v.innerText!==f&&(v.innerText=f)}const I=i.querySelector(".nwp-icon-mic-on"),y=i.querySelector(".nwp-icon-mic-off");if(I&&y){const f=this.inVoice&&!this.isMuted;I.style.display=f?"block":"none",y.style.display=f?"none":"block"}const k=document.getElementById("nwp-badge");if(k)if(this.unreadCount>0&&!this.isChatOpen){k.style.display="flex";const f=this.unreadCount>9?"9+":`${this.unreadCount}`;k.innerText!==f&&(k.innerText=f)}else k.style.display="none";const T=((s=(d=this.party)==null?void 0:d.members)==null?void 0:s.length)||1,V=document.getElementById("nwp-members-tooltip");if(V){const f=`Members (${T})`;V.innerText!==f&&(V.innerText=f)}const P=document.getElementById("nwp-members-card");if(P&&((h=this.party)!=null&&h.members)){const f=JSON.stringify(this.party.members.map(g=>({id:g.userId,name:g.name,v:g.inVoice,m:g.isMuted,s:g.isSpeaking})));this.lastRenderedMembersHash!==f&&(this.lastRenderedMembersHash=f,P.innerHTML=`
              <div style="font-weight:700;font-size:11px;color:#94a3b8;margin-bottom:4px;">WATCHERS (${this.party.members.length})</div>
              ${this.party.members.map(g=>`
                <div class="nwp-member-row">
                  <span>${g.name} ${g.isHost?"👑":""}</span>
                  <span style="color:${g.inVoice?g.isMuted?"#f87171":"#34d399":"#64748b"}">
                    ${g.inVoice?g.isMuted?"🔇":g.isSpeaking?"🗣️":"🎙️":"•"}
                  </span>
                </div>
              `).join("")}
            `)}}}if(this.chatDrawerElement){this.isChatOpen&&t?this.chatDrawerElement.classList.contains("nwp-open")||this.chatDrawerElement.classList.add("nwp-open"):this.chatDrawerElement.classList.contains("nwp-open")&&this.chatDrawerElement.classList.remove("nwp-open");const u=((N=this.party)==null?void 0:N.partyCode)||"",S=document.getElementById("nwp-drawer-code");S&&S.innerText!==u&&(S.innerText=u);const v=document.getElementById("nwp-chat-body");if(v){u!==this.lastPartyCode&&(this.lastPartyCode=u,v.innerHTML="",this.renderedMessageIds.clear()),this.messages.length===0&&v.children.length>0&&(v.innerHTML="",this.renderedMessageIds.clear());let I=!1;this.messages.forEach(y=>{var k;if(!this.renderedMessageIds.has(y.id)){this.renderedMessageIds.add(y.id),I=!0;const T=y.senderId===((k=this.currentUser)==null?void 0:k.userId),V=y.type==="system",P=document.createElement("div");P.dataset.msgId=y.id,V?(P.className="nwp-msg-bubble nwp-msg-system",P.innerText=y.text):(P.className=`nwp-msg-bubble ${T?"nwp-msg-mine":"nwp-msg-other"}`,y.type==="sticker"&&y.stickerUrl?P.innerHTML=`
                  ${T?"":`<div class="nwp-msg-sender">${y.senderName}</div>`}
                  <div style="font-size:26px;">${y.stickerUrl}</div>
                `:P.innerHTML=`
                  ${T?"":`<div class="nwp-msg-sender">${y.senderName}</div>`}
                  <div>${y.text}</div>
                `),v.appendChild(P)}}),I&&(v.scrollTop=v.scrollHeight)}}}toggleChat(t){if(t!==void 0?this.isChatOpen=t:this.isChatOpen=!this.isChatOpen,this.isChatOpen&&(this.unreadCount=0),this.updateDOM(),this.isChatOpen){const e=document.getElementById("nwp-chat-input");e&&setTimeout(()=>e.focus(),50)}}sendMessage(t,e="chat",i){l.sendMessage(t,e,i)}destroy(){this.container&&(this.container.remove(),this.container=null)}};o(M,"instance");let _=M;const U=_.getInstance(),x=A.getInstance();let O=0;console.log("[Netflix Watch Party] Content script active with persistent Party Engine.");U.init();b.getPartySession().then(r=>{r&&r.party&&U.updateState(r)}).catch(()=>{});var D;typeof chrome<"u"&&((D=chrome.storage)!=null&&D.onChanged)&&chrome.storage.onChanged.addListener((r,t)=>{if(t==="local"&&r.netflix_wp_party_session){const e=r.netflix_wp_party_session.newValue;if(e&&e.party){U.updateState(e);const i=l.getState().party;(!i||i.partyCode!==e.party.partyCode)&&l.joinParty(e.party.partyCode,e.currentUser).catch(()=>{})}else U.updateState({party:null,messages:[]}),l.getState().party&&l.leaveParty()}});function H(r){r.__wp_attached||(r.__wp_attached=!0,r.addEventListener("play",()=>{x.isHandlingRemoteAction()||l.handleLocalPlay(r.currentTime)}),r.addEventListener("pause",()=>{x.isHandlingRemoteAction()||l.handleLocalPause(r.currentTime)}),r.addEventListener("seeked",()=>{x.isHandlingRemoteAction()||l.handleLocalSeek(r.currentTime)}),r.addEventListener("timeupdate",()=>{const t=Date.now();t-O>1500&&(O=t,l.handleMediaUpdate(x.getMediaInfo()))}))}const z=new MutationObserver(()=>{const r=x.detectVideoElement();r&&H(r)});z.observe(document.body||document.documentElement,{childList:!0,subtree:!0});const B=x.detectVideoElement();B&&H(B);chrome.runtime.onMessage.addListener((r,t,e)=>{if(r.type==="GET_PARTY_ENGINE_STATE")return e({success:!0,state:l.getState()}),!0;if(r.type==="ENGINE_JOIN_PARTY"){const{partyCode:i,user:n}=r.payload||{};return l.joinParty(i,n).then(a=>{e(a)}),!0}if(r.type==="ENGINE_CREATE_PARTY"){const{name:i,description:n,onlyHost:a}=r.payload||{};return l.createParty(i,n,a).then(c=>{e({success:!!c,party:c})}),!0}if(r.type==="ENGINE_LEAVE_PARTY")return l.leaveParty(),e({success:!0}),!0;if(r.type==="ENGINE_TOGGLE_VOICE"||r.type==="FLOATING_ACTION_TOGGLE_VOICE"){const{inVoice:i}=r.payload||{};return i!==void 0?l.setVoiceState(i).then(()=>{e({success:!0,inVoice:l.getState().inVoice})}):l.toggleVoice().then(()=>{e({success:!0,inVoice:l.getState().inVoice})}),!0}if(r.type==="ENGINE_TOGGLE_MUTE"||r.type==="FLOATING_ACTION_TOGGLE_MUTE"){const i=l.toggleMute();return e({success:!0,isMuted:i}),!0}if(r.type==="ENGINE_SEND_MESSAGE"||r.type==="FLOATING_ACTION_SEND_CHAT"){const{text:i,type:n,stickerUrl:a}=r.payload||{};return l.sendMessage(i,n,a).then(()=>{e({success:!0})}),!0}if(r.type==="ENGINE_TOGGLE_PLAY")return l.togglePlay(),e({success:!0}),!0;if(r.type==="ENGINE_FORCE_SYNC"||r.type==="FLOATING_ACTION_RESYNC")return l.forceSync(),e({success:!0}),!0;if(r.type==="NETFLIX_GET_STATUS"){const i=window.location.hostname.includes("netflix.com"),n=x.detectVideoElement();return e({isNetflix:i,isPlaying:x.isPlaying(),currentTime:x.getCurrentTime(),duration:x.getDuration(),mediaInfo:x.getMediaInfo(),hasVideo:!!n}),!0}});
